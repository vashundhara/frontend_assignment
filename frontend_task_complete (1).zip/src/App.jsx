import React, {useEffect, useState, useMemo} from 'react';

const API_BASE = 'https://reqres.in/api/users';

function useUsers(page){
  const [data, setData] = useState({users:[], page:1, total_pages:1});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(()=>{
    let cancelled = false;
    async function fetchPage(){
      setLoading(true);
      setError(null);
      try{
        const url = `${API_BASE}?page=${page}&per_page=6`;
        const res = await fetch(url);
        if(!res.ok) throw new Error('Failed to fetch');
        const json = await res.json();
        if(!cancelled){
          setData({users: json.data || [], page: json.page || 1, total_pages: json.total_pages || 1});
        }
      }catch(err){ if(!cancelled) setError(err.message) }
      finally{ if(!cancelled) setLoading(false) }
    }
    fetchPage();
    return ()=>{ cancelled = true }
  },[page])

  return {data, loading, error}
}

export default function App(){
  const [page, setPage] = useState(1);
  const {data, loading, error} = useUsers(page);
  const [query, setQuery] = useState('');
  const [sortBy, setSortBy] = useState('first_name');
  const [sortDir, setSortDir] = useState('asc');
  const [filterType, setFilterType] = useState('none');
  const [filterValue, setFilterValue] = useState('');

  // derived list (client-side filtering/search/sort)
  const processed = useMemo(()=>{
    let list = [...(data.users||[])];
    // search
    if(query.trim()){
      const q = query.toLowerCase();
      list = list.filter(u => `${u.first_name} ${u.last_name}`.toLowerCase().includes(q) || (u.email||'').toLowerCase().includes(q));
    }
    // filter
    if(filterType === 'domain' && filterValue.trim()){
      const v = filterValue.toLowerCase();
      // allow with or without @
      const domain = v.startsWith('@') ? v.slice(1) : v;
      list = list.filter(u => (u.email||'').toLowerCase().endsWith(domain));
    }
    if(filterType === 'first-letter' && filterValue.trim()){
      const v = filterValue[0].toLowerCase();
      list = list.filter(u => (u.first_name||'').toLowerCase().startsWith(v));
    }
    // sort
    list.sort((a,b)=>{
      const A = ((a[sortBy]||'')+'').toLowerCase();
      const B = ((b[sortBy]||'')+'').toLowerCase();
      if(A < B) return sortDir==='asc' ? -1 : 1;
      if(A > B) return sortDir==='asc' ? 1 : -1;
      return 0;
    })
    return list;
  },[data.users, query, sortBy, sortDir, filterType, filterValue]);

  function toggleSort(field){
    if(sortBy === field){ setSortDir(d => d==='asc' ? 'desc' : 'asc') }
    else { setSortBy(field); setSortDir('asc') }
  }

  function handlePrev(){ setPage(p => Math.max(1,p-1)) }
  function handleNext(){ setPage(p => Math.min(data.total_pages, p+1)) }

  return (
    <div className="container">
      <div className="header">
        <h1>User Directory</h1>
        <div className="controls">
          <div className="controls-row">
            <input className="input" placeholder="Search by name or email" value={query} onChange={e=>setQuery(e.target.value)} />
            <select className="select" value={sortBy} onChange={e=>setSortBy(e.target.value)}>
              <option value="first_name">Sort: First name</option>
              <option value="email">Sort: Email</option>
            </select>
            <button className="btn" onClick={()=>setSortDir(d=>d==='asc'?'desc':'asc')}>{sortDir==='asc'?'Asc':'Desc'}</button>
          </div>
        </div>
      </div>

      <div style={{marginTop:12,display:'flex',gap:8,flexWrap:'wrap',alignItems:'center'}}>
        <label className="small">Filter:</label>
        <select className="select" value={filterType} onChange={e=>{ setFilterType(e.target.value); setFilterValue('') }}>
          <option value="none">None</option>
          <option value="domain">Email domain (e.g. reqres.in)</option>
          <option value="first-letter">First letter of first name</option>
        </select>
        {filterType === 'domain' && (
          <input className="input" placeholder="e.g. reqres.in" value={filterValue} onChange={e=>setFilterValue(e.target.value)} />
        )}
        {filterType === 'first-letter' && (
          <input className="input" placeholder="e.g. A" value={filterValue} onChange={e=>setFilterValue(e.target.value)} maxLength={1} />
        )}
        <button className="btn" onClick={()=>{ setQuery(''); setFilterType('none'); setFilterValue('') }}>Reset</button>
      </div>

      <div style={{marginTop:18}}>
        {loading ? (
          <div style={{display:'flex',justifyContent:'center',padding:40}}>
            <div className="spinner" role="status" aria-label="Loading"></div>
          </div>
        ) : error ? (
          <div style={{padding:20,background:'#fee2e2',borderRadius:8,color:'#7f1d1d'}}>Error: {error}</div>
        ) : (
          <table className="table" aria-label="User table">
            <thead>
              <tr>
                <th></th>
                <th style={{cursor:'pointer'}} onClick={()=>toggleSort('first_name')}>Name {sortBy==='first_name' ? (sortDir==='asc'?'▲':'▼') : ''}</th>
                <th style={{cursor:'pointer'}} onClick={()=>toggleSort('email')}>Email {sortBy==='email' ? (sortDir==='asc'?'▲':'▼') : ''}</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {processed.length === 0 ? (
                <tr><td colSpan={4} style={{padding:20}} className="small">No users found on this page with current filters.</td></tr>
              ) : (
                processed.map(user => (
                  <tr key={user.id}>
                    <td><img className="avatar" src={user.avatar} alt={`${user.first_name} avatar`} /></td>
                    <td>{user.first_name} {user.last_name}</td>
                    <td className="small">{user.email}</td>
                    <td><a className="btn" href={`mailto:${user.email}`}>Email</a></td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        )}

        <div className="pager" style={{justifyContent:'space-between'}}>
          <div className="small">API Page {data.page} / {data.total_pages}</div>
          <div style={{display:'flex',gap:8}}>
            <button className="btn" onClick={()=>setPage(1)} disabled={data.page===1}>First</button>
            <button className="btn" onClick={handlePrev} disabled={data.page===1}>Prev</button>
            <div style={{padding:'8px 10px',display:'flex',alignItems:'center',gap:8}}>
              <span className="small">Go to</span>
              <input className="input" style={{width:64}} type="number" min={1} max={data.total_pages} value={page} onChange={e=>{ const v = Number(e.target.value) || 1; setPage(Math.min(Math.max(1,v), data.total_pages)) }} />
            </div>
            <button className="btn" onClick={handleNext} disabled={data.page===data.total_pages}>Next</button>
            <button className="btn" onClick={()=>setPage(data.total_pages)} disabled={data.page===data.total_pages}>Last</button>
          </div>
        </div>

      </div>

    </div>
  )
}
