# User Directory - React

This is a simple React application that fetches users from `https://reqres.in/api/users` and displays them in a table.
Features:
- Fetch user list (paginated) from API
- Search by name or email
- Sort by first name or email (asc/desc)
- Pagination (uses API pages)
- Filter by email domain or first letter of first name
- Loading spinner
- Responsive layout (basic)

## Setup

1. Install dependencies:
```
npm install
```

2. Start dev server:
```
npm start
```

App will open at `http://localhost:3000`.

## Notes
- This project uses plain CSS for styling (no external UI framework) so it is simple to run.
- To deploy, build with `npm run build` and host the `build` folder on Netlify/Vercel or any static host.
